-- Cell class to handle individual cell logic

--[[Cell = {}
Cell.__index = Cell  -- UNCOMMENT THIS LINE

function Cell:new(row, col, index)
    local cell = {}  -- CREATE TABLE HERE
    setmetatable(cell, Cell)
    cell.row = row
    cell.col = col
    cell.status = "empty"
    cell.index = index
    return cell  -- MUST RETURN THE INSTANCE
end]]