function love.conf(t)
    t.window.title = "Tic-Tac-Toe"
    t.window.width = 1024
    t.window.height = 768
    t.window.resizable = true
    t.modules.joystick = false
    t.modules.physics = false
end