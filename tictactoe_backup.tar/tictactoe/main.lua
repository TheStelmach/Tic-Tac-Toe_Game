love = require("love")

function love.load()
    mouseX = 0
    mouseY = 0
    windowHeight = love.graphics.getHeight( )
    windowWidth = love.graphics.getWidth( )
    cellWidth = windowWidth / 3
    cellHeight = windowHeight / 3
    turn = "X"
    beepSound = love.audio.newSource("beepSound.mp3", "static")
    gameEndSound = love.audio.newSource("gameEnded.mp3", "static")

    r_back, g_back, b_back, a_back = 255/255, 251/255, 219/255, 0
    love.graphics.setBackgroundColor(r_back, g_back, b_back, a_back)

    r_line, g_line, b_line, a_line = 235/255, 216/255, 61/255, 1
    r_cross, g_cross, b_cross, a_cross = 255/255, 103/255, 77/255, 1
    r_circle, g_circle, b_circle, a_circle = 119/255, 118/255, 188/255, 1

    cellArray = {
        "empty", "empty", "empty",
        "empty", "empty", "empty",
        "empty", "empty", "empty"
    }
    winner = "unknown"
end

function love.update()
    windowHeight = love.graphics.getHeight( )
    windowWidth = love.graphics.getWidth( )

    cellWidth = windowWidth / 3
    cellHeight = windowHeight / 3
end


function love.draw()

    love.graphics.setColor( r_line, g_line, b_line, a_line )
    love.graphics.line( cellWidth, 0, cellWidth, windowHeight)
    love.graphics.line( 2 * cellWidth, 0, 2 * cellWidth, windowHeight)
    love.graphics.line( 0, cellHeight, windowWidth, cellHeight)
    love.graphics.line( 0, 2 * cellHeight, windowWidth, 2 * cellHeight)

    for i = 1, 3 do
        for j = 1, 3 do
        local index = (i - 1) * 3 + j
        if cellArray[index] == "X" then
            love.graphics.setColor( r_cross, g_cross, b_cross, a_cross )
            --DRAW A CROSS
            love.graphics.circle( "fill",
                          (j - 1) * cellWidth + cellWidth / 2,
                          (i - 1) * cellHeight + cellHeight / 2,
                          cellWidth / 4)
            
        elseif cellArray[index] == "O" then
            love.graphics.setColor( r_circle, g_circle, b_circle, a_circle )
            --DRAW A CIRCLE
            love.graphics.circle( "fill",
                          (j - 1) * cellWidth + cellWidth / 2,
                          (i - 1) * cellHeight + cellHeight / 2,
                          cellWidth / 4)
        end
    end
    end
    
end

function checkCell(row, col) 
    local cellIndex = 0
    if row == 1 and col == 1 then
        cellIndex = 1
    elseif row == 1 and col == 2 then
        cellIndex = 2
    elseif row == 1 and col == 3 then
        cellIndex = 3
    elseif row == 2 and col == 1 then
        cellIndex = 4
    elseif row == 2 and col == 2 then
        cellIndex = 5
    elseif row == 2 and col == 3 then
        cellIndex = 6
    elseif row == 3 and col == 1 then
        cellIndex = 7
    elseif row == 3 and col == 2 then
        cellIndex = 8
    elseif row == 3 and col == 3 then
        cellIndex = 9
    else 
        return false
    end
    if cellArray[cellIndex] ~= "empty" then
        return false
    else
        love.audio.play(beepSound)
        return true
    end
end

function do_X(row, col)
    if checkCell(row, col) then
        cellArray[(row - 1) * 3 + col] = "X"
    else
        print("Cell already occupied!")
    end
end

function do_O(row, col)
    if checkCell(row, col) then
    cellArray[(row - 1) * 3 + col] = "O"
    else
        print("Cell already occupied!")
    end
end



function makeBoard()

    print("Cell clicked: Row " .. row .. ", Column " .. col)
    if turn == "X" then
        do_X(row, col)
        --checkCell(row, col)
        turn = "O"
        print("X placed, now O's turn")
    else
        do_O(row, col)
        --checkCell(row, col)
        turn = "X"
        print("O placed, now X's turn")
    end
    
end

function checkforWin()
    -- Check rows, columns, and diagonals for a win
    -- If a win is detected, play gameEndSound and print the winner
    if winner ~= "unknown" then
        love.audio.play(gameEndSound)
        print("Game Over! Winner: " .. winner)
    end
end

function love.mousepressed( x, y, button, istouch, presses )
    if button == 1 then
        mouseX = x
        mouseY = y  
        col = math.floor(mouseX / cellWidth) + 1
        row = math.floor(mouseY / cellHeight) + 1
        makeBoard()
        checkforWin()
    end
end


-- IMPLEMENT CELL CLASSES AND A CIRCULAR BUFFER TO REMOVE FIRST ELEMENT